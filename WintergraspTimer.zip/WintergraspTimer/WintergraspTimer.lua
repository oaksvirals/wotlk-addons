-- WintergraspTimer.lua
-- Wintergrasp Timer Addon
-- Interface: 30300

local addonName, addonTable = ...
local isAlertMessagesEnabled = true
local wintergraspTimeLeft = 0 -- Time left until Wintergrasp starts
local lastAlert = "" -- To store the last alert message

-- Function to send messages
local function SendMessage(message, frame)
    if message ~= lastAlert then
        RaidNotice_AddMessage(frame, message, ChatTypeInfo["RAID_WARNING"])
        PlaySound(8959, "master")  -- Raid Warning sound ID
        lastAlert = message
    end
end

-- Function to get formatted time in hours, minutes, and seconds
local function GetFormattedTime(seconds)
    if seconds == 0 then
        return "In Progress"
    end

    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    local secs = seconds % 60

    if hours > 0 then
        return string.format("%d hours, %d minutes", hours, minutes)
    elseif minutes > 0 then
        return string.format("%d minutes", minutes)
    else
        return string.format("%d seconds", secs)
    end
end

-- Function to get Wintergrasp status and timer
local function GetWintergraspStatus()
    local duration = GetWintergraspWaitTime() or 0
    if duration < 1 then
        return "In Progress", 0
    else
        return "Waiting", duration
    end
end

-- Function to update Wintergrasp time
local function UpdateWintergraspTime()
    local status, duration = GetWintergraspStatus()
    wintergraspTimeLeft = duration
end

-- Function to announce Wintergrasp time to a channel
local function AnnounceWintergraspTime(channel)
    UpdateWintergraspTime()
    local status, timeString = GetWintergraspStatus()
    if status == "In Progress" then
        timeString = "In Progress"
    else
        timeString = GetFormattedTime(wintergraspTimeLeft)
    end
    SendChatMessage("Time until Wintergrasp: " .. timeString, channel)
end

-- Function to announce Wintergrasp status
local function AnnounceWintergrasp(frame)
    local status, duration = GetWintergraspStatus()
    if status == "Waiting" then
        local timeString = GetFormattedTime(duration)
        SendMessage("Wintergrasp battle starting in " .. timeString .. "!", frame)
    else
        SendMessage("Wintergrasp battle is currently in progress!", frame)
    end
end

-- Create the main frame for the GUI
local guiFrame = CreateFrame("Frame", "WintergraspTimerFrame", UIParent)
guiFrame:SetSize(300, 150)  -- Reduced height to 150
guiFrame:SetPoint("CENTER")
guiFrame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 }
})
guiFrame:SetBackdropColor(0, 0, 0, 1)
guiFrame:EnableMouse(true)
guiFrame:SetMovable(true)
guiFrame:RegisterForDrag("LeftButton")
guiFrame:SetScript("OnDragStart", guiFrame.StartMoving)
guiFrame:SetScript("OnDragStop", guiFrame.StopMovingOrSizing)
guiFrame:Hide()  -- Initially hide the GUI

-- Set the title of the frame
guiFrame.title = guiFrame:CreateFontString(nil, "OVERLAY")
guiFrame.title:SetFontObject("GameFontHighlightLarge")
guiFrame.title:SetPoint("TOP", guiFrame, "TOP", 0, -20)
guiFrame.title:SetText("Wintergrasp Timer")

-- Create the live countdown text
local liveCountdownText = guiFrame:CreateFontString(nil, "OVERLAY")
liveCountdownText:SetFontObject("GameFontNormal")
liveCountdownText:SetPoint("TOP", guiFrame.title, "BOTTOM", 0, -10)

local function UpdateLiveCountdown()
    UpdateWintergraspTime()
    local status, duration = GetWintergraspStatus()
    if status == "In Progress" then
        liveCountdownText:SetText("Time until Wintergrasp: In Progress")
    else
        liveCountdownText:SetText("Time until Wintergrasp: " .. GetFormattedTime(wintergraspTimeLeft))
    end
end

-- Create the Close button
local closeButton = CreateFrame("Button", nil, guiFrame, "UIPanelCloseButton")
closeButton:SetPoint("TOPRIGHT", guiFrame, "TOPRIGHT", -5, -5)
closeButton:SetScript("OnClick", function() guiFrame:Hide() end)

-- Function to create a checkbox
local function CreateCheckbox(name, parent, label, checked, callback)
    local checkbox = CreateFrame("CheckButton", name, parent, "UICheckButtonTemplate")
    checkbox:SetChecked(checked)
    checkbox:SetScript("OnClick", function(self)
        local isChecked = self:GetChecked()
        callback(isChecked)
    end)
    checkbox.text = checkbox:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    checkbox.text:SetPoint("LEFT", checkbox, "RIGHT", 10, 0)  -- Adjust the x and y offsets here
    checkbox.text:SetText(label)

    local container = CreateFrame("Frame", nil, parent)
    container:SetSize(checkbox:GetWidth() + checkbox.text:GetWidth() + 10, checkbox:GetHeight())
    checkbox:SetParent(container)
    checkbox:SetPoint("LEFT")
    checkbox.text:SetParent(container)
    checkbox.text:SetPoint("LEFT", checkbox, "RIGHT", 0, 0)

    return container
end

-- Create the checkbox for enabling/disabling alerts
local alertMessagesCheckbox = CreateCheckbox(
    "AlertMessagesCheckbox",
    guiFrame,
    "Enable Alert Messages",
    isAlertMessagesEnabled,
    function(checked) isAlertMessagesEnabled = checked end
)
alertMessagesCheckbox:SetPoint("TOP", liveCountdownText, "BOTTOM", 0, -5)  -- Reduced vertical spacing above

-- Create the send buttons
local sendToGuildButton = CreateFrame("Button", nil, guiFrame, "UIPanelButtonTemplate")
sendToGuildButton:SetSize(100, 30)
sendToGuildButton:SetText("Alert Guild")
sendToGuildButton:SetPoint("BOTTOM", guiFrame, "BOTTOM", -55, 10)  -- Centered and adjusted horizontally
sendToGuildButton:SetScript("OnClick", function() AnnounceWintergraspTime("GUILD") end)  -- Restored functionality

local sendToPartyButton = CreateFrame("Button", nil, guiFrame, "UIPanelButtonTemplate")
sendToPartyButton:SetSize(100, 30)
sendToPartyButton:SetText("Alert Party")
sendToPartyButton:SetPoint("BOTTOM", guiFrame, "BOTTOM", 55, 10)  -- Centered and adjusted horizontally
sendToPartyButton:SetScript("OnClick", function() AnnounceWintergraspTime("PARTY") end)  -- Restored functionality

-- Slash command to show the GUI
SLASH_WINTERGRASPTIMER1 = "/wgt"
SlashCmdList["WINTERGRASPTIMER"] = function()
    if guiFrame:IsShown() then
        guiFrame:Hide()
    else
        guiFrame:Show()
    end
end

-- Function to send alerts
local function SendAlert(message)
    if isAlertMessagesEnabled then
        SendMessage(message, RaidWarningFrame)
    end
end

-- Function to start a simple timer
local function SimpleTimer(duration, callback)
    local timer = CreateFrame("Frame")
    timer:Hide()
    timer.duration = duration
    timer.callback = callback
    timer:SetScript("OnUpdate", function(self, elapsed)
        self.duration = self.duration - elapsed
        if self.duration <= 0 then
            self:Hide()
            self.callback()
            self:SetScript("OnUpdate", nil)
        end
    end)
    timer:Show()
end

-- Function to handle Wintergrasp start timer
local function HandleWintergraspStart()
    UpdateWintergraspTime()
    local status = GetWintergraspStatus()
    if status == "Waiting" and wintergraspTimeLeft > 0 then
        if isAlertMessagesEnabled then
            SimpleTimer(wintergraspTimeLeft - 1800, function() SendAlert("30 minutes until Wintergrasp!") end)
            SimpleTimer(wintergraspTimeLeft - 900, function() SendAlert("15 minutes until Wintergrasp!") end)
            SimpleTimer(wintergraspTimeLeft - 600, function() SendAlert("10 minutes until Wintergrasp!") end)
            SimpleTimer(wintergraspTimeLeft - 300, function() SendAlert("5 minutes until Wintergrasp!") end)
            SimpleTimer(wintergraspTimeLeft - 60, function() SendAlert("1 minute until Wintergrasp!") end)
        end
    elseif status == "In Progress" then
        if isAlertMessagesEnabled then
            lastAlert = "Wintergrasp is currently in progress!"  -- Prevent repeated messages
        end
    end
end

-- Register event for updating Wintergrasp time
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" or event == "ZONE_CHANGED_NEW_AREA" then
        lastAlert = "" -- Reset the last alert on login or zone change
        HandleWintergraspStart()
    end
end)

-- Update the live countdown every second
local tickerFrame = CreateFrame("Frame")
tickerFrame:SetScript("OnUpdate", function(self, elapsed)
    self.elapsed = (self.elapsed or 0) + elapsed
    if self.elapsed >= 1 then
        UpdateLiveCountdown()
        self.elapsed = 0
    end
end)

print("Wintergrasp Timer add-on loaded. Type /wgt to show the GUI.")
